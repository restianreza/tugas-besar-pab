package com.reza.dinosaurus.Model;

public class ModelDino {
    private  String id, nama, jenis, ukuran, asal, deskripsi;
    public String getId() {
        return id;
    }

    public String getNama() {
        return nama;
    }

    public String getJenis() {
        return jenis;
    }

    public String getUkuran() {
        return ukuran;
    }

    public String getAsal() {
        return asal;
    }

    public String getDeskripsi() {
        return deskripsi;
    }
}